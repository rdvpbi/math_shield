# 🚀 БЫСТРЫЙ СТАРТ: От репозитория до APK

## Шаг 1: Загрузите на GitHub (5 минут)

```bash
# Распакуйте архив
unzip math_shield_github.zip
cd math_shield_github

# Инициализируйте Git
git init
git add .
git commit -m "Initial commit: Math Shield project"

# Создайте репозиторий на GitHub.com, затем:
git remote add origin https://github.com/ВАШ_ЛОГИН/math_shield.git
git branch -M main
git push -u origin main
```

---

## Шаг 2: Подключите Claude Code (2 минуты)

1. Откройте **[claude.ai/code](https://claude.ai/code)**
2. Нажмите **"Connect GitHub"**
3. Выберите репозиторий **math_shield**
4. Готово!

---

## Шаг 3: Выполните задачи (30-60 минут)

Откройте файл `READY_COMMANDS.md` и выполняйте задачи по порядку.

**Минимальный набор для рабочего APK:**
1. Задача 1.1 (константы)
2. Задача 2.1 (entities)
3. Задача 5.1 (тема)
4. Задача 7.1 (экраны)
5. Задача 8.1 (навигация)
6. Задача 10.1 (main.dart)

---

## Шаг 4: Получите APK (автоматически!)

После каждого commit GitHub автоматически:
1. Запускает сборку
2. Создаёт APK
3. Сохраняет как Artifact

### Как скачать APK:

1. Зайдите на GitHub → ваш репозиторий
2. Нажмите вкладку **Actions**
3. Выберите последний зелёный ✅ workflow "Build APK"
4. Прокрутите вниз до **Artifacts**
5. Нажмите **math-shield-apk** → скачается ZIP с APK

![GitHub Actions](https://docs.github.com/assets/cb-15465/images/help/repository/actions-tab-global-nav-update.png)

---

## 📱 Установка APK на телефон

1. Скачайте APK на телефон
2. Откройте файл
3. Разрешите установку из неизвестных источников
4. Установите
5. Играйте! 🎮

---

## ⚡ Быстрые команды

### Запуск сборки вручную:
1. GitHub → Actions → Build APK
2. Нажмите **"Run workflow"**
3. Дождитесь завершения (~5 минут)

### Создание релиза:
```bash
git tag v1.0.0
git push origin v1.0.0
```
→ Автоматически создаст GitHub Release с APK

---

## ❓ Проблемы и решения

| Проблема | Решение |
|----------|---------|
| Сборка падает | Проверьте вкладку Actions → логи ошибок |
| Нет Artifacts | Дождитесь завершения workflow (зелёная галочка) |
| APK не устанавливается | Включите "Неизвестные источники" в настройках |
| Код не компилируется | Создайте задачу: "Исправь ошибки flutter analyze" |

---

## 🎯 Готово!

Теперь у вас есть:
- ✅ Репозиторий на GitHub
- ✅ Автоматическая сборка APK
- ✅ Готовые задачи для Claude Code
- ✅ Понятный путь к готовой игре

Удачи! 🛡️🎮
