# 🛡️ Math Shield

> Образовательная игра для детей 5-9 лет: изучение таблицы умножения через платформер с боссами.

![Flutter](https://img.shields.io/badge/Flutter-02569B?style=for-the-badge&logo=flutter&logoColor=white)
![Dart](https://img.shields.io/badge/Dart-0175C2?style=for-the-badge&logo=dart&logoColor=white)
![Riverpod](https://img.shields.io/badge/Riverpod-00D1B2?style=for-the-badge)

---

## 🎮 О проекте

**Math Shield** — мобильная игра, которая превращает изучение таблицы умножения в увлекательное приключение. Ребёнок путешествует по 10 мирам, каждый из которых посвящён одному множителю (от ×0 до ×9), и сражается с боссами, решая математические примеры.

### Особенности:
- 🌍 **10 уникальных миров** — от Лабиринта Нуля до Дворца Девяти Зеркал
- 👾 **10 боссов** с уникальными механиками
- 🦉 **Ментор Филин** — помогает и подсказывает
- 🎯 **Адаптивная сложность** — подстраивается под уровень ребёнка
- 🔥 **Combo-система** — награждает за серии правильных ответов
- 👶 **UI для детей** — большие кнопки, яркие цвета, минимум текста

---

## 🏗️ Архитектура

Проект построен на **Clean Architecture + MVVM + Riverpod**:

```
lib/
├── core/           # Константы, утилиты, ошибки
├── domain/         # Entities, UseCases, Repository interfaces
├── data/           # Models, DataSources, Repository implementations
├── application/    # Controllers, Services, State
├── presentation/   # Screens, Widgets, Dialogs, Theme
├── navigation/     # GoRouter
└── audio/          # Аудио система
```

---

## 🚀 Быстрый старт

```bash
# Клонируйте репозиторий
git clone https://github.com/YOUR_USERNAME/math_shield.git
cd math_shield

# Установите зависимости
flutter pub get

# Запустите на эмуляторе
flutter run

# Соберите APK
flutter build apk --release
```

---

## 🤖 Разработка с Claude Code

Этот проект создан для генерации кода с помощью [Claude Code](https://claude.ai/code).

### Файлы для Claude:
- **CLAUDE.md** — Инструкции и правила архитектуры
- **SPEC.md** — Полное техническое задание
- **TASKS.md** — Список задач по порядку

### Запуск:
1. Подключите репозиторий к Claude Code на [claude.ai/code](https://claude.ai/code)
2. Создайте новую задачу
3. Скопируйте текст задачи из `TASKS.md`
4. Запустите и отслеживайте прогресс

---

## 📁 Структура документации

| Файл | Описание |
|------|----------|
| `CLAUDE.md` | Инструкции для Claude Code: архитектура, правила кода, стиль |
| `SPEC.md` | Полное ТЗ: лор, механики, UI, технические требования |
| `TASKS.md` | Пошаговые задачи для генерации проекта |

---

## 🎨 Дизайн

### Цветовая палитра
- Primary: `#6C5CE7` (фиолетовый)
- Secondary: `#00CEC9` (бирюзовый)
- Accent: `#FDCB6E` (золотой)
- Background: `#1A1A2E` (тёмно-синий)

### UI для детей
- Кнопки: минимум 64×64 dp
- Шрифты: крупные, читаемые
- Минимум текста, максимум иконок

---

## 📋 Требования

- Flutter 3.16+
- Dart 3.2+
- Android SDK 23+ (Android 6.0)

---

## 📄 Лицензия

MIT License — свободное использование.

---

## 👥 Авторы

Создано с помощью Claude Code от Anthropic.
